from re import search
from unicodedata import category

from django.shortcuts import render
from .models import Product, Category
# Create your views here.
def show_product(request):
    products = Product.objects.select_related('category').all()
    categories = Category.objects.all()
    #поиск данных
    search_query = request.GET.get('search', '')
    if search_query:
        products = Product.filter(name__icontains=search_query)

    filter_query = request.GET.get('filter_product', '')
    if filter_query:
        products = Product.filter(category=filter_query)

    context = {
        'my_products': products,
        'search_value': search_query,
        'filter_product': filter_query,
        'my_category': categories


    }

    return render(request, 'index.html', context)