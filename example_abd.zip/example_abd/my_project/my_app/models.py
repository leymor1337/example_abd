from django.db import models

# Create your models here.
class Category(models.Model):
    name = models.CharField()
    description = models.CharField()

class Product(models.Model):
    name = models.CharField()
    cost = models.DecimalField(max_digits=10, decimal_places=2)
    production_date = models.DateField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='category')